//
//  MainView.swift
//  Tab View
//
//  Created by Ufuk Köşker on 4.09.2020.
//  Copyright © 2020 Ufuk Köşker. All rights reserved.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView{
            ContentView()
                .tabItem {
                    Text("1. Sayfa")
                    Image(systemName: "1.circle.fill")
            }
            
            SecondView()
                .tabItem {
                    Text("2. Sayfa")
                    Image(systemName: "2.circle.fill")
            }
        }
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
