//
//  SecondView.swift
//  Tab View
//
//  Created by Ufuk Köşker on 4.09.2020.
//  Copyright © 2020 Ufuk Köşker. All rights reserved.
//

import SwiftUI

struct SecondView: View {
    var body: some View {
        Text("2. Sayfa")
    }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView()
    }
}
