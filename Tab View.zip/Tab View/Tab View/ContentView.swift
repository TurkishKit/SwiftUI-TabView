//
//  ContentView.swift
//  Tab View
//
//  Created by Ufuk Köşker on 4.09.2020.
//  Copyright © 2020 Ufuk Köşker. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Text("1. Sayfa")
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
